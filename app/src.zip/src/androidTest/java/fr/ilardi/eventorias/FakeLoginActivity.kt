package fr.ilardi.eventorias

import android.app.Activity
import android.os.Bundle

class FakeLoginActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setResult(RESULT_OK)
        finish()
    }
}