package fr.ilardi.eventorias

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.test.core.app.ApplicationProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.storage.FirebaseStorage
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import fr.ilardi.eventorias.repository.AuthenticationRepository

import io.mockk.*
@Module
@InstallIn(SingletonComponent::class)
object TestAppModule {

    // Si un AuthenticationRepository mocké est nécessaire :
    @Provides
    fun provideAuthenticationRepository(firebaseAuth: FirebaseAuth, firebaseStorage: FirebaseStorage): AuthenticationRepository {
        return mockk(relaxed = true)
    }
}