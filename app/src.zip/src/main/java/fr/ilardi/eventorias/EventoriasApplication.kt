package fr.ilardi.eventorias

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class EventoriasApplication : Application() {

}