package fr.ilardi.eventorias.model

data class User(
    val name: String = "",
    val email: String = "",
    val profileImage: String = "",
    val uid: String = ""
)