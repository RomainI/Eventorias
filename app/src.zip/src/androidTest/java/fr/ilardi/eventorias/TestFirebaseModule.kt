package fr.ilardi.eventorias.di

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.storage.FirebaseStorage
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import io.mockk.mockk
import javax.inject.Singleton
@Module
@InstallIn(SingletonComponent::class)
object TestFirebaseModule {

    @Provides
    @Singleton
    fun provideFirebaseFirestore(): FirebaseFirestore {
        return mockk(relaxed = true)
    }

    // Gardez ce module uniquement si vous souhaitez tester les interactions avec Firestore
}