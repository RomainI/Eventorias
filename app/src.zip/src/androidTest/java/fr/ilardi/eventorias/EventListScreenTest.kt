package fr.ilardi.eventorias.ui.screens

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.navigation.NavHostController
import androidx.navigation.compose.rememberNavController
import dagger.hilt.android.testing.HiltAndroidRule
import dagger.hilt.android.testing.HiltAndroidTest
import fr.ilardi.eventorias.MainActivity
import fr.ilardi.eventorias.viewmodel.LoginViewModel
import io.mockk.every
import io.mockk.mockk
import org.junit.Before
import org.junit.Rule
import org.junit.Test

@HiltAndroidTest
class EventListScreenTest {

    @get:Rule(order = 0)
    val hiltRule = HiltAndroidRule(this)

    @get:Rule(order = 1)
    val composeRule = createAndroidComposeRule<MainActivity>()

    private lateinit var navController: NavHostController

    @Before
    fun setup() {
        hiltRule.inject()  // Initialise Hilt
        composeRule.setContent {
            navController = rememberNavController()
            LoginScreen(
                onLoginAction = { navController.navigate("event_list") },
                loginViewModel = mockLoginViewModel()
            )
        }
    }

    @Test
    fun loginScreenNavigatesToEventListScreen() {
        // Simuler la connexion réussie
        navController.navigate("event_list")

        // Vérifier que l’écran EventListScreen est bien atteint
        composeRule.onNodeWithTag("EventListScreen").assertIsDisplayed()
    }

    // Mock du ViewModel pour ne pas dépendre de Firebase pendant les tests
    private fun mockLoginViewModel(): LoginViewModel {
        val viewModel = mockk<LoginViewModel>()
        every { viewModel.getLoginIntent() } returns mockk()  // Mock l’intent de Firebase
        return viewModel
    }
}