package fr.ilardi.eventorias

import androidx.activity.ComponentActivity
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithTag
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.test.ext.junit.runners.AndroidJUnit4
import dagger.hilt.android.testing.HiltAndroidRule
import dagger.hilt.android.testing.HiltAndroidTest
import dagger.hilt.android.testing.UninstallModules
import fr.ilardi.eventorias.di.AppModule
import fr.ilardi.eventorias.ui.screens.LoginScreen
import fr.ilardi.eventorias.viewmodel.LoginViewModel
import org.junit.Before
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import javax.inject.Inject

@UninstallModules(AppModule::class)
@HiltAndroidTest
@RunWith(AndroidJUnit4::class)
class LoginScreenTest {

    @get:Rule(order = 0)
    val hiltRule = HiltAndroidRule(this)

    @get:Rule(order = 1)
    val composeTestRule = createAndroidComposeRule<MainActivity>()

    @Inject
    lateinit var loginViewModel: LoginViewModel

    @Before
    fun setup() {
        hiltRule.inject()
    }

    @Test
    fun loginScreenDisplaysCorrectScreen() {
        composeTestRule.setContent {
            LoginScreen(onLoginAction = {}, loginViewModel = hiltViewModel())
        }
        composeTestRule.waitForIdle()

        composeTestRule.onNodeWithTag("DisplayLoginScreen").assertIsDisplayed()
    }
}