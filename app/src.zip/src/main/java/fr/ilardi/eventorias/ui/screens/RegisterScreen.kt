package fr.ilardi.eventorias.ui.screens

class RegisterScreen {
}